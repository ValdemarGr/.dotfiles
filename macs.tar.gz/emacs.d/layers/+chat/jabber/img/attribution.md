This image (jabber-logo.gif) is a derivative of an image owned and
copyrighted by the Jabber Software Foundation and released under the
[CC-BY 2.5 license](http://creativecommons.org/licenses/by/2.5/),
which is available at
[at Wikimedia Commons](http://commons.wikimedia.org/wiki/File:Jabber_logo.png).
